valor = 0;
  contagem = 0;

  function recalculateCart()
{
  var subtotal = 0;
  
  /* Sum up row totals */
  $('.product').each(function () {
    subtotal += parseFloat($(this).children('.product-line-price').text());
  });
  
  /* Calculate totals */
  var tax = subtotal * taxRate;
  var shipping = (subtotal > 0 ? shippingRate : 0);
  var total = subtotal + tax + shipping;
  
  /* Update totals display */
  $('.totals-value').fadeOut(fadeTime, function() {
    $('#cart-subtotal').html(subtotal.toFixed(2));
    $('#cart-tax').html(tax.toFixed(2));
    $('#cart-shipping').html(shipping.toFixed(2));
    $('#cart-total').html(total.toFixed(2));
    if(total == 0){
      $('.checkout').fadeOut(fadeTime);
    }else{
      $('.checkout').fadeIn(fadeTime);
    }
    $('.totals-value').fadeIn(fadeTime);
  });
}
  function FunMS() {
  var checkBox = document.getElementById("CheckMS");
  var text = document.getElementById("MS");
  if (checkBox.checked == true){
    text.style.display = "block";
    contagem = contagem + 1;
    valor = valor+12;
  } else {
    text.style.display = "none";
    contagem = contagem - 1;
    valor = valor -12;
  }
}
function FunMF() {
  checkBox = document.getElementById("CheckMF");
  text = document.getElementById("MF");
  if (checkBox.checked == true){
    text.style.display = "block";
    contagem = contagem + 1;
    valor = valor+8;
  } else {
     text.style.display = "none";
     contagem = contagem - 1;
     valor = valor -8;
  }
}

function FunAF() {
  var checkBox = document.getElementById("CheckAF");
  var text = document.getElementById("AF");
  if (checkBox.checked == true){
    text.style.display = "block";
    contagem = contagem + 1;
    valor = valor+5;
  } else {
     text.style.display = "none";
     contagem = contagem - 1;
     valor = valor -5;
  }
}
function PromoCode(){
  var botao = document.getElementById("ButtonPC");
  var promo = document.getElementById("PC");
  var txt = document.getElementById("PromoTXT").value;
  var promoccode = txt.toLowerCase()
    if (promoccode == "ezbook"){
    promo.style.display = "block";
    valor = valor -5;
    }  
}